package com.patanjali.attendencemodule.service;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.patanjali.attendencemodule.database.SharedPrefrenceUtil;
import com.patanjali.attendencemodule.model.DateTimeModel;
import com.patanjali.attendencemodule.model.LatitudeModel;
import com.patanjali.attendencemodule.model.LongitudeModel;
import com.patanjali.attendencemodule.model.MultipleLatLonRequest;
import com.patanjali.attendencemodule.model.MultipleLatLongResponse;
import com.patanjali.attendencemodule.network.ApiInterface;
import com.patanjali.attendencemodule.network.NetworkUtility;
import com.patanjali.attendencemodule.network.RetrofitClientInstance;
import com.patanjali.attendencemodule.singletonclass.SingletonClass;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Patanjali on 23-12-2018.
 */

public class WorkerService extends Worker {


    public WorkerService(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

     ArrayList<String> machinedataa = new ArrayList<>();
    ArrayList<String> saveCheckedItem = new ArrayList<>();

    private static final int ID_SERVICE = 101;

    public static boolean isServiceRunning = false;

    private static final String TAG = LocationMotironingService.class.getSimpleName();

    private final int UPDATE_INTERVAL = 180000000;
    //1800000
    private final int FASTEST_INTERVAL = 170000000;
    GoogleApiClient mLocationClient;
    LocationRequest mLocationRequest;

    ProgressDialog mprogressDialog;
    String date_time;

    TextView employeename,text_checkin;

    TextView employee_code;

    Realm realm;
    List<LatitudeModel> results= new ArrayList<>();
    boolean image_value=true;

    ImageView sammary;

    List<LongitudeModel> longitudeModel=new ArrayList<>();

    List<DateTimeModel> datetimelist=new ArrayList<>();

    @NonNull
    @Override
    public Result doWork() {

       // PostFarmerDetail();

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(),"workmangaertest",Toast.LENGTH_LONG).show();
                Log.d("checkwork","worktime");
                //Your UI code here
            }
        });

        //isServiceRunning = true;
        postCheckoutdata();
        return Result.success();

    }

    public void postCheckoutdata() {

        Calendar call = Calendar.getInstance();
        DateFormat dff = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        String date_time = dff.format(call.getTime());
        final SharedPrefrenceUtil sharedPrefrenceUtil = new SharedPrefrenceUtil(getApplicationContext());
        String empcode = sharedPrefrenceUtil.getName();
        //  showLoadingDialog(this);
        Realm.init(getApplicationContext());
        realm = Realm.getDefaultInstance();
        results = realm.where(LatitudeModel.class).findAll();
        longitudeModel = realm.where(LongitudeModel.class).findAll();
        datetimelist = realm.where(DateTimeModel.class).findAll();
        final List<String> latList = new ArrayList<>();
        for (LatitudeModel model : results) {
            // latList.add(0,"ffff");
            latList.add(model.getLatitude() + "");
            Log.d("latlist", "" + latList);
        }
        final List<String> longList = new ArrayList<>();
        for (LongitudeModel model : longitudeModel) {
            longList.add(model.getLongitude() + "");
        }

        final List<String> multipledatetimelist = new ArrayList<>();
        for (DateTimeModel model : datetimelist) {
            multipledatetimelist.add(model.getDatetime() + "");
        }

        if (SingletonClass.getInstance().getCheckoutlatiude() != 0) {
            MultipleLatLonRequest loginRequestt = new MultipleLatLonRequest(empcode, latList, longList, date_time, multipledatetimelist);
            ApiInterface mapiClinet = RetrofitClientInstance.getApiClient();
            mapiClinet.docheckout(loginRequestt).enqueue(new Callback<MultipleLatLongResponse>() {

                @Override
                public void onResponse(@NonNull Call<MultipleLatLongResponse> call, @NonNull Response<MultipleLatLongResponse> response) {

                    // hideLoading();
                    if (NetworkUtility.isNetworkAvailable(getApplicationContext())) {

                        if (response.body() != null) {
                            Boolean status = response.body().getStatus();
                            //  int as = response.code();

                            if (status.equals(true)) {
                                //stopService(new Intent(getApplicationContext(), LocationMotironingService.class));
                                Toast.makeText(getApplicationContext(), "Your Location Successfully Send to Server", Toast.LENGTH_LONG).show();
                                //   RealmResults<LatitudeModel> results = realm.where(LatitudeModel.class).findAll();

                                realm.beginTransaction();
                                realm.delete(LatitudeModel.class);
                                realm.delete(LongitudeModel.class);
                                realm.delete(DateTimeModel.class);
                                //results.deleteAllFromRealm();
                                realm.commitTransaction();

                            }

                        } else {
                            Toast.makeText(getApplicationContext(), "Something Went Wrong...Try Again!!", Toast.LENGTH_LONG).show();

                        }

                    } else {
                        Toast.makeText(getApplicationContext(), "PLs Check Your Internet Connection", Toast.LENGTH_LONG).show();
                    }

                    //  showTaost(msg);
                }

                @Override
                public void onFailure(Call<MultipleLatLongResponse> call, Throwable t) {

                    //  hideLoading();
                    Toast.makeText(getApplicationContext(), "Something Went Wrong....", Toast.LENGTH_LONG).show();
                    // Toast.makeText(getApplicationContext(),"Something Went Wrong .....Try Again", Toast.LENGTH_LONG).show();

                }

            });
        } else {
            Toast.makeText(getApplicationContext(), "Please Wait While we are Fetching the Location", Toast.LENGTH_LONG).show();

        }
    }
}

